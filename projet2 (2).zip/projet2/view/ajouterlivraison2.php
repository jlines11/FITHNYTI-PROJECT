<?php

include '../Controller/livraisonC2.php';

$error = "";

// create livraison
$livraison = null;

// create an instance of the controller
$g_livraison = new traitement_livraison();
if ( isset($_POST["etat"]) && isset($_POST["address_depart"])&& isset($_POST["address_arrive"])  && isset($_POST["tel"])  &&  isset($_POST["date"]) ) {
    if (!empty($_POST["etat"]) &&!empty($_POST["address_depart"])   &&!empty($_POST["address_arrive"])   &&!empty($_POST["tel"])    &&!empty($_POST["date"]) ) 
    {
        $livraison = new livraison(  null, $_POST['etat'], $_POST['address_depart'] , $_POST['address_arrive'] , $_POST['tel'], new DateTime($_POST['date']) );
        $g_livraison->add_livraison($livraison);
       // header('Location:ListClients.php');
    } else
        $error = "Missing information";
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Display</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        hr {
            border: 1px solid #ccc;
        }

        #error {
            color: red;
            font-weight: bold;
        }

        form {
            margin-top: 20px;
            text-align: center;
        }

        table {
            border-collapse: collapse;
            width: 50%;
            margin: auto;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        input[type="text"],
        input[type="date"],
        input[type="submit"],
        input[type="reset"] {
            width: 100%;
            padding: 8px;
            margin: 5px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type="submit"],
        input[type="reset"] {
            background-color: #4caf50;
            color: white;
            cursor: pointer;
        }

        input[type="submit"]:hover,
        input[type="reset"]:hover {
            background-color: #45a049;
        }
      

    </style>
</head>

<body>
    <hr>

    <div id="error">
        <?php echo $error; ?>
    </div>
   
   
<center>
    <h2>formulaire de colis </h2>
</center>


    <form action="" method="POST">
        <table border="2" align="center">

            <!- <tr>
                <td>
                    <label for="Nom et prénom">Nom et prénom</label>
                </td>
                <td><input type="text" name="" id="Nom et prénom" maxlength="20"></td>
            </tr>
            <tr>
                <td>
                    <label for="etat">etat du colis</label>
                </td>
                <td><input type="text" name="etat" id="etat" maxlength="20"></td>
            </tr>
            <tr>
                <td>
                    <label for="address_depart">Address du depart :</label>
                </td>
                <td>
                    <input type="text" name="address_depart" id="address_depart">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="address_arrive">Adresse d'arrivée  :</label>
                </td>
                <td>
                    <input type="text" name="address_arrive" id="address_arrive">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="tel">telephone :</label>
                </td>
                <td>
                    <input type="text" name="tel" id="tel">
                </td>
            </tr>
            <tr>
                <td>
                    <label for="date">Date:</label>
                </td>
                <td>
                    <input type="date" name="date" id="date">
                </td>
            </tr>
            <tr align="center">
                <td>
                    <input type="submit" value="Save">
                </td>
                <td>
                    <input type="reset" value="Reset">
                </td>
            </tr>
     

        </table>
    </form>
    

</body>


</html>